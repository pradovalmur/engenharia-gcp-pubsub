from google.cloud import pubsub_v1

publisher = pubsub_v1.PublisherClient()

futures = dict()

def get_callback(f, data):
    def callback(f):
        try:
            print(f.result())
            futures.pop(data)
        except:  # noqa
            print("Please handle {} for {}.".format(f.exception(), data))
    return callback

def quote_price(request):
    topic_path = 'projects/testeengenharia/topics/quote_price'
    valueAttribute = str(request.get_json().get('quoteprice'))
    future = publisher.publish(topic_path, data=valueAttribute.encode("utf-8"))
    futures[data] = future
    future.add_done_callback(get_callback(future, data))
    return future

def bill_materials(request):
    topic_path = 'projects/testeengenharia/topics/bill_materials'
    valueAttribute = request.get_json().get('billmaterials')
    future = publisher.publish(topic_path, data=valueAttribute.encode("utf-8"))
    futures[data] = future
    future.add_done_callback(get_callback(future, data))
    return future

def comp_boss(request):
    topic_path = 'projects/testeengenharia/topics/comp_boss'
    valueAttribute = request.get_json().get('compboss')
    future = publisher.publish(topic_path, data=valueAttribute.encode("utf-8"))
    futures[data] = future
    future.add_done_callback(get_callback(future, data))
    return future

def trigger(request):
    try:
        request.get_json().get('quoteprice')
        quote_price(request)
        return f'Dados inseridos no topico quote_price'
    except:
        try:
            request.get_json().get('billmaterials')
            bill_materials(request)
            return f'Dados inseridos no topico bill_materials'
        except:
            try:
                request.get_json().get('compboss')
                comp_boss(request)
                return f'Dados inseridos no topico comp_boss'
            except:
                return f'Sem topico de referencia, criar novo topico'
